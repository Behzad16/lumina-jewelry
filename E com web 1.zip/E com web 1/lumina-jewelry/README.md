# Lumina Jewelry — Website

A complete, responsive, high-converting storefront for a luxury jewelry brand.
Built as a **zero-dependency static site**: plain HTML, CSS and JavaScript, no build
step, no framework, no npm install. Open `index.html` in a browser and it runs.

---

## 1. What's here

| Page | File | Notes |
|---|---|---|
| Home | `index.html` | Hero, trust strip, collections, best sellers / new arrivals / under $500 tabs, story, testimonial carousel, Instagram grid, newsletter |
| Shop | `shop.html` | Filter by category, collection, price, sale, new · sort · search · load more · shareable filtered URLs |
| Product detail | `product.html?p=<handle>` | Gallery, metal & size options, quantity, add to bag, wishlist, accordions, review summary + review form, related products |
| About | `about.html` | Story, stats, values, atelier process, team |
| Contact | `contact.html` | Validated contact form, studio details, hours, map link |
| FAQ | `faq.html` | 24 questions in 6 sections, accordion, deep-linkable |
| Privacy Policy | `privacy.html` | |
| Terms & Conditions | `terms.html` | |
| Not found | `404.html` | Branded, with best sellers |

Supporting files: `sitemap.xml`, `robots.txt`, `site.webmanifest`, `netlify.toml`,
`vercel.json`.

### File layout

```
lumina-jewelry/
├── index.html  shop.html  product.html
├── about.html  contact.html  faq.html
├── privacy.html  terms.html  404.html
├── sitemap.xml  robots.txt  site.webmanifest
├── netlify.toml  vercel.json
└── assets/
    ├── css/styles.css      one stylesheet, sectioned and commented
    ├── js/data.js          the product catalogue — the only file most edits touch
    ├── js/main.js          shared: header, drawers, cart, wishlist, search, forms, animation
    ├── js/shop.js          shop filtering / sorting / pagination
    ├── js/product.js       product detail page + structured data
    └── img/                36 SVG placeholders (see §4)
```

---

## 2. Running it locally

No tooling required — double-click `index.html`.

If you want it served over HTTP (recommended, and required if you add anything
that uses `fetch`), any static server will do:

```bash
npx serve .
```

---

## 3. Deploying

### Netlify (recommended)
Drag the `lumina-jewelry` folder onto <https://app.netlify.com/drop>, or connect
the repo — `netlify.toml` is already configured (no build command, security
headers, cache headers, pretty-URL redirects, 404 handling).

### Vercel
`vercel.json` is included. Import the repo, framework preset **Other**, leave the
build command empty and the output directory as the root.

### Any host
It is static — upload the folder to S3, Cloudflare Pages, or shared hosting as-is.

**After deploying:** search-and-replace `https://www.luminajewelry.com/` with the
real domain across the `.html` files, `sitemap.xml` and `robots.txt`. That string
appears in canonical tags, Open Graph URLs and structured data.

---

## 4. Images

`assets/img/` holds 36 hand-generated SVG placeholders — gold line art on
champagne, ivory, blush, stone and onyx backgrounds. They are deliberately
lightweight (about 1 KB each) and elegant, but they are **placeholders for real
product photography**.

To swap in real photos, keep the same filenames and aspect ratios:

| Files | Aspect | Used for |
|---|---|---|
| `ring-1…5`, `necklace-1…5`, `earring-1…5`, `bracelet-1…5` | 1:1 | Product cards and PDP galleries |
| `hero.svg` | ~16:10 | Home hero |
| `collection-aurora/celeste/eclat.svg` | 3:4 | Featured collection cards |
| `story-atelier.svg`, `story-craft.svg` | 4:5 | About / home story blocks |
| `team-1…3.svg` | 3:4 | Team portraits |
| `insta-1…6.svg` | 1:1 | Instagram grid |
| `og-cover.svg` | 1200×630 | Social sharing card |

If you switch to `.jpg`/`.webp`, update the paths in `assets/js/data.js`
(`galleries` object) and in the `<img src>` attributes of the HTML pages. Keep the
`width`/`height` attributes accurate — they prevent layout shift.

Product photography specifically: shoot square, on a light neutral background,
1600×1600 or larger, then export at ~1000×1000 as WebP.

---

## 5. Editing the catalogue

Everything about products lives in **`assets/js/data.js`**. Add a product by
copying an existing `make({...})` block:

```js
make({
  id: 21, handle: 'aurora-halo-ring', name: 'Aurora Halo Ring',
  category: 'rings',            // rings | necklaces | earrings | bracelets
  collection: 'aurora',         // aurora | celeste | eclat | heritage
  price: 1150, compareAt: null, // compareAt renders a strikethrough + save badge
  rating: 4.8, reviews: 41,
  badges: ['new'],              // 'new' and/or 'bestseller'
  tags: ['halo', 'engagement'], // searchable keywords
  added: '2026-07-15',          // drives "newest first" sorting
  excerpt: 'One line for search results and meta descriptions.',
  description: 'A paragraph for the product page.',
  details: ['Bullet one', 'Bullet two']
})
```

The new product then appears automatically in the shop, filters, search, sitemap
candidates and related-product logic. Remember to add its URL to `sitemap.xml`.

Other things you may want to change in `data.js`: `L.testimonials` (home page
carousel) and `L.reviews` (per-product reviews, keyed by handle).

Global settings elsewhere:
- Free-shipping threshold — `FREE_SHIPPING` at the top of `assets/js/main.js`
- Products per page on the shop — `PAGE_SIZE` at the top of `assets/js/shop.js`
- Colours, fonts, spacing — the `:root` custom properties in `assets/css/styles.css`

---

## 6. Forms

Both the contact form and the newsletter form are marked `data-demo`, which means
they validate fully and show a success message **without** submitting anywhere.
That keeps the demo self-contained.

To make the contact form live on Netlify, delete `data-demo` from the `<form>` tag
in `contact.html`. Everything else Netlify Forms needs (`data-netlify="true"`, the
hidden `form-name` input, and the honeypot) is already in place; submissions will
appear under **Forms** in the Netlify dashboard.

For any other host, point the form at your endpoint (Formspree, Basin, your own
API) with `action` and `method`, and remove `data-demo`.

The newsletter form should be wired to your email platform (Klaviyo, Mailchimp,
Omnisend) — replace the form element with the embed snippet they give you, or POST
to their API.

---

## 7. What is and isn't wired up

**Working, no back end needed:** product browsing, search, filtering, sorting,
cart (persisted in `localStorage`), wishlist (persisted), quantity editing,
free-shipping progress, review submission (stored locally), form validation,
all animations and responsive behaviour.

**Needs a service before launch:**
- **Checkout.** The "Proceed to checkout" button currently shows a notice. Wire it
  to Shopify Buy Button, Stripe Checkout, Snipcart or similar — the cart contents
  are available as `LUMINA.Store.cart`.
- **Contact / newsletter delivery** (see §6).
- **Analytics.** Nothing is loaded today. If you add GA4, Meta Pixel or similar,
  you also need a cookie consent banner — the privacy policy already promises that
  analytics and marketing cookies are only set after consent.
- **Legal review.** `privacy.html` and `terms.html` are thorough, well-structured
  drafts written for a US direct-to-consumer jewelry business. Have an attorney
  review them before taking real orders.

Placeholder details to replace throughout: the address (148 Greene Street),
phone (+1 212-555-0184), emails (`care@` / `privacy@luminajewelry.com`) and the
social media URLs.

---

## 8. Performance & SEO

- No frameworks, no jQuery, no CSS libraries. One stylesheet (47 KB) plus two or
  three small scripts per page — roughly 100 KB of text uncompressed, about 25 KB
  over the wire once your host gzips it. The only external request is Google
  Fonts, preconnected and loaded with `display=swap`.
- The 36 SVG placeholders total 52 KB for the whole site — around 1.4 KB each.
- All below-the-fold images are `loading="lazy"` with explicit dimensions; the
  hero is preloaded with `fetchpriority="high"`.
- Semantic HTML with one `<h1>` per page, descriptive `alt` text throughout.
- Unique title and meta description on every page, plus canonical URLs and Open
  Graph / Twitter cards.
- Structured data: `Organization` + `WebSite` (with SearchAction) on the home page,
  `BreadcrumbList` on shop and product, `Product` with offers and aggregate rating
  on every product page, `FAQPage` on the FAQ, `ContactPage`/`JewelryStore` on
  contact, `AboutPage` on about.
- `sitemap.xml` covers all pages, categories, collections and 20 products;
  `robots.txt` points at it and blocks low-value filter permutations.

To self-host the fonts (removes the last third-party request and shaves ~150ms),
download the two families, drop the `.woff2` files into `assets/fonts/`, and
replace the Google Fonts `<link>` with `@font-face` rules in `styles.css`.

---

## 9. Accessibility

Skip link, visible focus rings, full keyboard operation, focus trapping in
drawers, Escape to close, ARIA on tabs / accordions / drawers / toggles,
`aria-live` regions for cart and toast updates, labelled form fields with inline
error messages, and a `prefers-reduced-motion` block that disables all animation.

---

## 10. Porting to Shopify

The brief mentioned Shopify as a platform preference. This build is deliberately
structured so that port is mechanical rather than a rewrite:

| Static site | Shopify equivalent |
|---|---|
| Repeated `<header>` / `<footer>` markup | `sections/header.liquid`, `sections/footer.liquid` |
| `assets/js/data.js` | Shopify products — delete the file, the data comes from Liquid |
| `LUMINA.productCard()` | `snippets/product-card.liquid` |
| `shop.html` + `shop.js` | `templates/collection.liquid` with native `filter.v.price` / tag filters |
| `product.html` + `product.js` | `templates/product.liquid` (variants replace the metal/size swatches) |
| Cart drawer in `main.js` | `/cart.js` AJAX API — same drawer markup, different data source |
| Review form | Shopify Product Reviews, Judge.me or Okendo |
| `faq.html`, `about.html`, legal pages | Pages with `page.content` |

The CSS transfers unchanged — it has no dependency on where the markup comes from.

---

*Built for Sarah Williams · Lumina Jewelry*
